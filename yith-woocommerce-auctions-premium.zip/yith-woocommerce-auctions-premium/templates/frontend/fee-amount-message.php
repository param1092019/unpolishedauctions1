<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

?>

<div class="ywcact-fee-amount-message ">

    <div class="ywcact-fee-amount-container <?php echo ($user) ? 'yith-wcact-popup-button' : '' ?>" data-ywcact-content-id=".yith-wcact-fee-modal">
        <span class="ywcact-fee-amount-title" style="font-weight: bold;"><?php echo esc_html__('This is a bidding fee auction.','yith-auctions-for-woocommerce') ?></span></br>

        <span class="ywcact-fee-amount-content">
	        <?php echo apply_filters( 'yith_wcact_fee_amount_message', sprintf( esc_html_x('All participants must pay a non-refundable fee of %s to place bids', 'All participants must pay a non-refundable fee of $5 to place bids' ,'yith-auctions-for-woocommerce'), wc_price( $fee_amount ) ), $fee_amount ); ?>
        </span>

    </div>

</div>

<?php
	if ( $user ) {
		?>
		<div class="yith-wcact-fee-modal"
			 style="display: none">

			<div class="yith-wcact-modal-title">
				<h3><?php echo  esc_html__( 'Pay the fee and start now to bid!','yith-auctions-for-woocommerce')?></h3>

			</div>
			<div class="yith-wcact-modal-content">
				<span><?php esc_html_e('This is a bidding fee auction.','yith-auctions-for-woocommerce');?></span></br>
				<p>
					<?php echo apply_filters( 'yith_wcact_fee_amount_message_modal', sprintf( esc_html__( "To participate you must pay a non-refundable fee of %s, then you'll immediately be able to bid.", 'yith-auctions-for-woocommerce' ), '<span class="ywcact-price">'.wc_price( $fee_amount ).'</span>'), $fee_amount ) ?>
				</p>
			</div>
			<div class="yith-wcact-modal-buttons">
				<input type="hidden" name="yith-wcact-pay-fee-auction-value" value="<?php echo esc_attr( $fee_amount ); ?>"/>
				<button type="button" class="button alt ywcact-modal-button ywcact-modal-button-pay-fee"><?php esc_html_e('Pay now', 'yith-auctions-for-woocommerce'); ?></button>
			</div>
		</div>

		<?php
 	}
?>
