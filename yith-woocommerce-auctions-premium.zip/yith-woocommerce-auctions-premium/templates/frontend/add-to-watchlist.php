<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

?>

<div class="ywcact-add-to-watchlist ywcact-add-to-watchlist-<?php echo esc_attr( $product_id ); ?> <?php echo esc_attr( $container_classes ); ?>">
	<?php if ( ! $ajax_loading ): ?>
		<!-- ADD TO WATCHLIST -->

		<?php
		if( 'button' == $template_part ) {

			?>
			<div class="yith-wcact-add-to-watchlist-button">
				<img class="yith-wcact-add-to-watchlist-icon" src="<?php echo $icon;?>">
				<span class="yith-wcact-add-to-watchlist-button-message">
					<a href="<?php echo esc_url( add_query_arg( array( 'add_to_watchlist' => $product_id, 'user_id' => $user_id ), $base_url ) ); ?>" rel="nofollow" class="add_to_watchlist <?php echo esc_attr( $link_class ) ?>" data-product-id="<?php echo esc_attr( $product_id ) ?>" data-user-id="<?php echo esc_attr( $user_id ) ?>" data-title="<?php echo esc_attr( apply_filters( 'yith_wcact_add_to_watchlist_title', $add_watchlist_text ) ); ?>">
						<span><?php echo wp_kses_post( $add_watchlist_text ); ?></span>
					</a>
					<!-- COUNT TEXT -->
					<?php
					if( $show_count && $users_has_product > 0 ) {
						?>
						<span class="add-to-watchlist-number-of-users">
							<?php
							/* translators: %s number of products in watchlist 10 Users watching */
							echo sprintf( esc_html__( '%s Users watching', 'yith-auctions-for-woocommerce' ), $users_has_product );

							?>
						</span>
						<?php
					} else {
						?>
						<span><?php echo esc_html__('Be the first to watch','yith-auctions-for-woocommerce'); ?></span>
						<?php
					}
					?>
				</span>
			</div>

			<?php


		} elseif( 'browse' == $template_part ) {

			?>
			<div class="yith-wcact-add-to-watchlist-browse">
				<img class="yith-wcact-add-to-watchlist-icon" src="<?php echo $icon;?>">
				<span class="yith-wcact-add-to-watchlist-browse-message">
					<a href="<?php echo esc_url( $watchlist_url ); ?>" rel="nofollow" data-product-id="<?php echo esc_attr( $product_id ) ?>" data-title="<?php echo esc_attr( apply_filters( 'yith_wcact_add_to_watchlist_title', $add_watchlist_text ) ); ?>">
						<span><?php echo wp_kses_post( $already_in_watchlist_text ); ?></span>
					</a>
					<!-- COUNT TEXT -->
					<?php
					if( $show_count && $users_has_product > 0 ) {
						?>
						<span class="add-to-watchlist-number-of-users">
							<?php
							/* translators: %s number of products in watchlist 10 Users watching */
							echo sprintf( esc_html__( '%s Users watching', 'yith-auctions-for-woocommerce' ), $users_has_product );

							?>
						</span>
						<?php
					}
					?>
				</span>
			</div>

			<?php
		}
		?>


	<?php endif; ?>
</div>