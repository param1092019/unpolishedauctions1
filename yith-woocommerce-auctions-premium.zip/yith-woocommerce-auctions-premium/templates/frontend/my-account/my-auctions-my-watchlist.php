<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

$instance = YITH_Auctions()->bids;
$user_id  = get_current_user_id();
$date     = date( "Y-m-d H:i:s" );

$auctions_by_user = $instance->get_whatchlist_product_by_user( $user_id );

?>

<div class="ywcact-return-to-watchlist">
	<a  href="<?php echo $default_url; ?>" class="ywcact-view-all-auction-list ywcact-my-account-link">
		<?php echo esc_html__('< Back', 'yith-auctions-for-woocommerce'); ?>
	</a>
</div>

<input class="ywcact-my-acount-auction-template" data-type="my-watchlist" type="hidden">

<table class="shop_table shop_table_responsive my_account_orders yith_wcact_my_auctions_my_watchlist">
    <thead>
        <tr>
			<th class="product-remove"> </th>
			<th class="toptable order-number"><span class="nobr" ><?php echo esc_html__( 'Image', 'yith-auctions-for-woocommerce' ); ?></span></th>
            <th class="toptable order-status"><span class="nobr"><?php echo esc_html__( 'Product', 'yith-auctions-for-woocommerce' ); ?></span></th>
            <th class="toptable order-date"><span class="nobr"><?php echo esc_html__( 'Your bid', 'yith-auctions-for-woocommerce' ); ?></span></th>
            <th class="toptable order-total"><span class="nobr"><?php echo esc_html__( 'Current bid', 'yith-auctions-for-woocommerce' ); ?></span></th>
            <th class="toptable order-actions"><span class="nobr"><?php echo esc_html__( 'End on:', 'yith-auctions-for-woocommerce' ); ?></span></th>

        </tr>
    </thead>
    <tbody>
    <?php
    foreach ( $auctions_by_user as $valor ) {
        $product      = wc_get_product( $valor->auction_id );
        if ( !$product )
            continue;
        
        $product_name = get_the_title( $valor->auction_id );
        $product_url  = get_the_permalink( $valor->auction_id );
        $a            = $product->get_image( );

		$auction_product_type = $product->get_auction_type();

		$max_bid = $auction_product_type && 'reverse' === $auction_product_type ? $instance->get_min_bid( $valor->auction_id ) : $instance->get_max_bid( $valor->auction_id );
		$max_bid_value = $max_bid ? $max_bid->bid : 0;

	    $bids = YITH_Auctions()->bids;
	    $last_bid_user = $bids->get_last_bid_user( $user_id, $valor->auction_id );
	    $auction_date = $product->is_start() ? $product->get_end_date() : $product->get_start_date();

	    if( $max_bid && $max_bid->user_id == $user_id) {
            $color = 'yith-wcact-max-bidder';
        }else{
            $color = 'yith-wcact-outbid-bidder';
        }
        ?>
            <tr class="yith-wcact-auction-my-watchlist-endpoint" data-product="<?php echo $product->get_id() ?>" >
				<td class="product-remove">
					<a href="<?php echo esc_url( add_query_arg( array( 'remove_from_watchlist' => $product->get_id(), 'user_id' => $user_id ) ) ); ?>" class="remove remove_from_watchlist" title="<?php echo esc_html( apply_filters( 'yith_wcwl_remove_product_wishlist_message_title', __( 'Remove this product', 'yith-auctions-for-woocommerce' ) ) ); ?>">&times;</a>
				</td>
                <td class="yith-wcact-auction-image" data-title="Image"><?php echo $a ?></td>
                <td class="product-url" data-title="Product"><a href="<?php echo $product_url; ?>"><?php echo $product_name ?></a></td>
                <td class="yith-wcact-my-bid yith-wcact-my-auctions <?php echo $color ?>" data-title="Your bid"><?php echo apply_filters('yith_wcact_auction_product_price', wc_price( $last_bid_user ), $last_bid_user, $currency); ?></td>
                <td class="yith-wcact-current-bid yith-wcact-my-auctions" data-title="Current bid"><?php echo 'yes' != $product->get_auction_sealed() ? apply_filters( 'yith_wcact_auction_product_price',wc_price( $product->get_price() ), $product->get_price(), $currency) : esc_html__('Sealed','yith-auctions-for-woocommerce'); ?></td>
				<td class="yith-wcact-end-on">

					<div class="yith-wcact-timeleft-widget-watchlist">
						<?php
							if( ! $product->is_closed() ) {
								$args = array(
									'product'           => $product,
									'auction_finish'    =>  $product->get_end_date(),
									'date'              => strtotime('now'),
									'last_minute'       => isset( $time_change_color ) ? $auction_end - $time_change_color  : 0,
									'total'             => $auction_date - strtotime('now'),
									'yith_wcact_class'  => isset( $yith_wcact_class ) ? $yith_wcact_class : 'yith-wcact-timeleft-default',
									'yith_wcact_block' => isset( $countdown_blocks ) ? $countdown_blocks : '',

								);
								wc_get_template( 'auction-timeleft.php', $args, '', YITH_WCACT_TEMPLATE_PATH . 'frontend/' );
							} else {

								echo esc_html__('Finished','yith-auctions-for-woocommerce');
							}
						?>
					</div>
				</td>
            </tr>
        <?php
    }
    ?>
    </tbody>

</table>