<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( $product instanceof WC_Product && 'auction' === $product->get_type() ) {

		?>
		<div class="yith-wcact-table-bids">

			<input type="hidden" id="yith-wcact-product-id" name="yith-wcact-product" value="<?php echo esc_attr( $product->get_id() ); ?>">
			<?php
			if ( apply_filters( 'yith_wcact_show_list_bids', true ) ) {
				?>
				<?php
				$product_sealed = $product->get_auction_sealed();
				$instance     = YITH_Auctions()->bids;
				$comparison_value = 'reverse' === $product->get_auction_type() ? '>' : '<'; // Display values for reverse or normal auctions.
				$auction_price = apply_filters('yith_wcact_auction_bid',$product->get_price(),$currency);

				if ( 'yes' == $product_sealed ) {

					$auction_list = is_user_logged_in() ? $instance->get_bids_auction( apply_filters( 'yith_wcact_auction_product_id', $product->get_id() ), get_current_user_id() ) : array() ;

				?>
					<div class="ywcact-list-bids-secret-auction">
						<p class="ywcact-list-bids-secret-auction-message">
							<?php echo apply_filters( 'yith_wcact_list_bids_secret_auction_message', esc_html__('You can see only your bids because this is a sealed auction', 'yith-auctions-for-woocommerce') ); ?>
						</p>
        			</div>

				<?php

				} else {
					$auction_list = $instance->get_bids_auction( apply_filters( 'yith_wcact_auction_product_id', $product->get_id() ) );
				}


				if ( count( $auction_list ) === 0 ) {

					if( 'no' === $product_sealed  ) {
						?>
						<p id="single-product-no-bid"> <?php ( !$product->is_start() ) ? esc_html_e( 'This auction has not been started yet.', 'yith-auctions-for-woocommerce' ) : esc_html_e( 'There are no bids yet. Be the first!', 'yith-auctions-for-woocommerce' ); ?></p>

						<?php
					}
                } else {
                    ?>
                    <table id="datatable" class="ywcact-list-bids-table">
                        <tr>
                            <td class="toptable"><?php echo esc_html__('Username', 'yith-auctions-for-woocommerce'); ?></td>
                            <td class="toptable"><?php echo esc_html__('Bid Amount', 'yith-auctions-for-woocommerce'); ?></td>
                            <td class="toptable"><?php echo apply_filters('yith_wcact_datetime_table', esc_html__('Date', 'yith-auctions-for-woocommerce')); ?></td>
                        </tr>
                        <?php
                        $option = get_option('yith_wcact_settings_tab_auction_show_name');
                        foreach ($auction_list as $object => $id) {
                            $user = get_user_by('id', $id->user_id);
                            $username = ($user) ? $user->data->user_nicename : apply_filters('yith_wcact_display_user_anonymous_name','anonymous',$user);

                            if ( 'no' == $option || apply_filters('yith_wcact_tab_auction_show_name',false,$id->user_id) ) {

                                $len = strlen($username);
                                $start = 1;
                                $end = 1;
                                $username = substr($username, 0, $start) . str_repeat('*', $len - ($start + $end)) . substr($username, $len - $end, $end);
                            }

                            if ($object == 0 && ( 'yes' !== $product_sealed ) ) {
                                $bid = $product->get_price();
                                ?>
                                <tr>
                                    <td><?php echo $username ?></td>
                                    <td><?php echo apply_filters('yith_wcact_auction_product_price' ,wc_price( $bid, array('currency' => $currency) ), $bid, $currency ); ?></td>
                                    <td class="yith_auction_datetime"><?php echo $id->date ?></td>
                                </tr>
                                <?php
                            } elseif ( yith_wcact_auction_compare_bids( $id->bid, $comparison_value, $auction_price ) ) {
                                $bid = $id->bid;
                                ?>
                                <tr>
                                    <td><?php echo $username ?></td>
                                    <td><?php echo apply_filters('yith_wcact_auction_product_price',wc_price($bid),$bid,$currency); ?></td>
                                    <td class="yith_auction_datetime"><?php echo $id->date ?></td>
                                </tr>
                                <?php
                            }
                        }
                        if ( $product->is_start() && $auction_list && ( 'yes' !== $product_sealed ) ) {

							$date_format = get_option('yith_wcact_general_date_format','j/n/Y');
							$time_format = get_option('yith_wcact_general_time_format','H:i:s');
							$auction_start_formatted = date($date_format . ' ' . $time_format, $product->get_start_date() );
                            ?>
                            <tr>
                                <td><?php esc_html_e('Start auction', 'yith-auctions-for-woocommerce') ?></td>
                                <td><?php echo apply_filters('yith_wcact_auction_product_price',wc_price($product->get_start_price(),$currency),$product->get_start_price(),$currency); ?></td>
                                <td class="yith_auction_datetime_shop" data-finnish-shop="<?php echo $product->get_start_date() ?>"><?php echo $auction_start_formatted; ?></td>
                            </tr>
                            <?php
                        }
                        ?>

                    </table>
                    <?php
                    if ( count($auction_list) == 0 ) {
                        ?>

                        <p id="single-product-no-bid"><?php esc_html_e('There is no bid for this item', 'yith-auctions-for-woocommerce'); ?></p>

                        <?php
                    }
                }
             }
            ?>
        </div>
<?php }  ?>