<?php
/**
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 **/

$item_args = array(
	'color'	=> isset( $color ) && $color ? $color : false,
);

?>

<div class="ywcact-other-auctions-section">

	<?php
		if( $heading_message && ! empty( $heading_message ) ) {
			?>
			<p class="ywcact-other-auction__heading"> <?php echo $heading_message ?>  </p>
			<?php
		}
	?>

	<div class="ywcact-other-auctions-container">
		<ul class="ywcact-other-auctions-list">

		<?php
		foreach ( $items as $item ) {

			$item_args['product'] = $item;
			wc_get_template( 'frontend/shortcodes/other-auctions-item.php', $item_args, '', YITH_WCACT_TEMPLATE_PATH );
		}
		?>
		</ul>

	</div>


</div>