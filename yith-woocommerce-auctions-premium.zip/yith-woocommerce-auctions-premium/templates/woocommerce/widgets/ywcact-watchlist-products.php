<?php
/**
 * Watchlist widget products
 *
 * @author  YITH
 * @package YITH Auctions for WooCommerce
 * @version 2.0.0
 */



// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="ywcact-watchlist-container-list" data-watchlist-product-counter="<?php echo count( $watchlist_products ) ?>">

	<?php if ( ! empty( $watchlist_products ) ) : ?>
		<ul class="watchlist_list">
			<?php
			foreach ( $watchlist_products as $watchlist_product ) :

				$product = wc_get_product( $watchlist_product->auction_id );
				/**
				 * @var $product \WC_Product
				 */
				if( !$product ) {
					continue;
				}
				/**
				 * @var $product \WC_Product
				 */
				?>
				<li>
					<a href="<?php echo esc_url( add_query_arg( array( 'remove_from_watchlist' => $product->get_id(), 'user_id' => $user_id ) ) ); ?>" class="remove_from_watchlist" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>"data-user-id="<?php echo esc_attr( $user_id ); ?>">&times;</a>
					<a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="image-thumb">
						<?php echo $product->get_image(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</a>
					<div class="mini-watchlist-item-info ywcact-product-watchlist">
						<a href="<?php echo esc_url( $product->get_permalink() ); ?>"><?php echo esc_html( $product->get_title() ); ?></a>
						<small class="mini-watchlist-item-current-bid"> <?php echo $product->get_price_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> </small>
						<div class="mini-watchlist-item-end-date">
							<small> <?php echo ( $product->is_start() ) ? esc_html('End time:','yith-auctions-for-woocommerce') : esc_html('Start time:','yith-auctions-for-woocommerce'); ?> </small>
							<?php
							$auction_date = $product->is_start() ? $product->get_end_date() : $product->get_start_date();

							$args = array(
								'product'           => $product,
								'auction_finish'    => $product->get_end_date(),
								'date'              => strtotime('now'),
								'last_minute'       => isset( $time_change_color ) ? $auction_end - $time_change_color  : 0,
								'total'             => $auction_date - strtotime('now'),
								'yith_wcact_class'  => isset( $yith_wcact_class ) ? $yith_wcact_class : 'yith-wcact-timeleft-default',
								'yith_wcact_block' => isset( $countdown_blocks ) ? $countdown_blocks : '',

							);
							?>
							<div class="yith-wcact-timeleft-widget-watchlist">
								<?php
								wc_get_template( 'auction-timeleft.php', $args, '', YITH_WCACT_TEMPLATE_PATH . 'frontend/' );
								?>
							</div>
						</div>
					</div>

				</li>
			<?php endforeach; ?>
		</ul>
	<?php else : ?>
		<p class="empty-wishlist">

			<?php

				if( is_user_logged_in()  ) {
					echo  apply_filters( 'yith_wcact_widget_items_empty_watchlist_list', esc_html__( 'Please, add your first item to the watchlist', 'yith-auctions-for-woocommerce' ) );
				} else {
					echo sprintf( esc_html__( 'Please, %s to use the watchlist feature','yith-auctions-for-woocommerce' ), '<a href='.get_permalink( get_option('woocommerce_myaccount_page_id') ).'>'. esc_html__('login','yith-auctions-for-woocommerce')  .'</a>' );
				}
			?>
		</p>
	<?php endif; ?>

</div>