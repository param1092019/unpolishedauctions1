<?php
/**
 * Email for user when the user is the winner of the auction
 *
 * @author  Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
$label_pay_now        = get_option( 'yith_wcact_auction_winner_label_pay_now', false );
$pay_now_button_label = $label_pay_now ? $label_pay_now : esc_html__( 'Pay now', 'yith-auctions-for-woocommerce' );


$base      = get_option( 'woocommerce_email_base_color' );
$base_text = wc_light_or_dark( $base, '#202020', '#ffffff' );

?>

<?php do_action( 'woocommerce_email_header', $email_heading, $email ); ?>

    <h2>
		<?php
		esc_html_e(
			'You are the winner!',
			'yith-auctions-for-woocommerce'
		);
		?>
    </h2>
    <p>
		<?php
		printf(
			esc_html__(
				'Congratulations  %s, you are the winner of the auction item:',
				'yith-auctions-for-woocommerce' ),
			$email->object['user_name'] );

		?>
    </p>

    <?php
        $args = array(
            'product'      => $email->object['product'],
            'url'          => $email->object['url_product'],
            'product_name' => $email->object['product_name'],
        );
        wc_get_template('product-email.php', $args, '', YITH_WCACT_PATH .'templates/emails/product-emails/');

        $url = add_query_arg( array( 'yith-wcact-pay-won-auction' => $email->object['product_id'] ), home_url() );
    ?>
	<p><?php esc_html_e( 'Pay for the item now to avoid losing it!', 'yith-auctions-for-woocommerce' ); ?></p>

	<div style="text-align: center; margin-top: 60px !important; margin-bottom: 10px !important;" >
		<a style="padding:10px 50px !important;font-size: 12px !important; background: <?php echo $base ?> !important; color: <?php echo $base_text ?> !important; text-decoration: none!important; text-transform: uppercase!important; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif !important;font-weight: 800 !important; border-radius: 3px !important; display: inline-block !important;" href="<?php echo esc_attr( apply_filters( 'yith_wcact_winner_email_pay_now_url', $url,$email ) )  ?>"><?php echo esc_html( $pay_now_button_label ) ?></a>
	</div>



<?php do_action( 'woocommerce_email_footer', $email );



//wc_get_template