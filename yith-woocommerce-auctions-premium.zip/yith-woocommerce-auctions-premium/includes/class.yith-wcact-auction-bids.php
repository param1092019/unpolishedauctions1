<?php
/**
 * Notes class
 *
 * @author  Yithemes
 * @package YITH WooCommerce Auctions
 * @version 1.0.0
 */

if ( ! defined( 'YITH_WCACT_VERSION' ) ) {
    exit( 'Direct access forbidden.' );
}


if ( !class_exists( 'YITH_WCACT_Bids' ) ) {
    /**
     * YITH_WCACT_Bids
     *
     * @since 1.0.0
     */
    class YITH_WCACT_Bids {

        /**
         * Single instance of the class
         *
         * @var \YITH_WCACT_Bids
         * @since 1.0.0
         */
        protected static $instance;

        public $table_name = '';
        public $table_name_fee = '';
        public $table_watchlist = '';


        /**
         * Returns single instance of the class
         *
         * @return \YITH_WCACT_Bids
         * @since 1.0.0
         */
        public static function get_instance() {
            $self = __CLASS__ . ( class_exists( __CLASS__ . '_Premium' ) ? '_Premium' : '' );

            if ( is_null( $self::$instance ) ) {
               $self::$instance = new $self;
            }

            return $self::$instance;
        }

        /**
         * Constructor
         *
         * @since  1.0.0
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         */
        public function __construct() {
            global $wpdb;
            $this->table_name      = $wpdb->prefix . YITH_WCACT_DB::$auction_table;
            $this->table_name_fee  = $wpdb->prefix . YITH_WCACT_DB::$fee_table;
            $this->table_watchlist = $wpdb->prefix . YITH_WCACT_DB::$watchlist_table;
        }

        /**
         * @param        $user_id
         * @param        $auction_id
         * @param        $bid
         * @param        $date
         */
        public function add_bid( $user_id, $auction_id, $bid, $date) {
            global $wpdb;

            $insert_query = "INSERT INTO $this->table_name (`user_id`, `auction_id`, `bid`, `date`) VALUES ('" . $user_id . "', '" . $auction_id . "', '" . $bid . "' , '" . $date . "' )";
            $wpdb->query( $insert_query );
			
			
			$user_info = get_userdata($user_id);
			
			$content = '<p class="contentbg">$'.$bid.' bid placed by '.$user_info->user_login.'</p>';
			$insert_query1 = "INSERT INTO wp_comments ( `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`)  VALUES ( '" . $auction_id . "' , '" . $user_info->user_login . "', '" . $user_info->user_email . "','','','".current_time( 'mysql' )."','".get_gmt_from_date( current_time( 'mysql' ) )."', '".$content."', '0', '1', '', 'review', '', '".$user_id."'  )";
           //update_option("test1",$insert_query1);
		   
		    $wpdb->query( $insert_query1 );
			$lastid = $wpdb->insert_id;
			 add_comment_meta( $lastid, 'verified', '0' );
        }
 
        /**
         * @param $auction_id
         *
         * @return array|null|object
         */
        public function get_bids_auction( $auction_id, $user_id = false ) {

			global $wpdb;

			$auction = wc_get_product($auction_id);


			$order_by =  ( $auction && 'auction' == $auction->get_type() && 'reverse' == $auction->get_auction_type() ) ? 'ASC' : 'DESC';

			$order_by = stripslashes($order_by);

			if ( isset( $user_id ) && $user_id > 0 ) {
				$query   = $wpdb->prepare( "SELECT * FROM $this->table_name WHERE auction_id = %d AND user_id = %d  ORDER by CAST( bid AS decimal(50,5))".$order_by.", date ASC", $auction_id, $user_id );
			} else {
				$query   = $wpdb->prepare( "SELECT * FROM $this->table_name WHERE auction_id = %d ORDER by CAST( bid AS decimal(50,5))".$order_by.", date ASC", $auction_id );

			}


			$results = $wpdb->get_results( $query );

			return $results;
        }
		/**
		 * @param $auction_id
		 *
		 * @return array|null|object
		 */
		public function get_bidders( $auction_id ) {

			global $wpdb;

			$query   = $wpdb->prepare( "SELECT user_id, count(user_id) FROM $this->table_name WHERE auction_id = %d GROUP by user_id", $auction_id );

			$results = $wpdb->get_results( $query );

			return $results;
		}

        /**
         * @param $auction_id
         *
         * @return array|null|object
         */
        public function get_tab_bid( $product_id, $current_bid ) {
            global $wpdb;

            $query   = $wpdb->prepare( "SELECT * FROM $this->table_name WHERE auction_id = %d AND bid >= %d ORDER by date ASC", $product_id, $current_bid );
            $results = $wpdb->get_results( $query );

            return $results;
        }



        /**
         * @param $auction_id
         *
         * @return array|null|object
         */
        public function get_max_bid($product_id){
            global $wpdb;

            $query   = $wpdb->prepare( "SELECT * FROM $this->table_name WHERE auction_id = %d ORDER by CAST(bid AS decimal(50,5)) DESC, date ASC LIMIT 1", $product_id );
            $results = $wpdb->get_row( $query );

            return $results;
        }

		/**
		 * @param $auction_id
		 *
		 * @return array|null|object
		 */
		public function get_min_bid($product_id){
			global $wpdb;

			$query   = $wpdb->prepare( "SELECT * FROM $this->table_name WHERE auction_id = %d ORDER by CAST(bid AS decimal(50,5)) ASC, date ASC LIMIT 1", $product_id );
			$results = $wpdb->get_row( $query );

			return $results;
		}

        /**
         * @param $auction_id
         *
         * @return array|null|object
         */
        public function get_last_two_bids($product_id ,$type ='normal'){
            global $wpdb;

            $bids = array();
            $first_bid = 'reverse' == $type ? $this->get_min_bid($product_id) : $this->get_max_bid( $product_id );
            if($first_bid){
                $bids[] = $first_bid;
                if ( isset($first_bid->user_id) ) {

                	if( 'reverse' == $type ) {
						$query = $wpdb->prepare( "SELECT * FROM $this->table_name WHERE auction_id = %d AND user_id <> %d ORDER by CAST(bid AS decimal(50,5)) ASC, date ASC LIMIT 1",$product_id,$first_bid->user_id);

					} else {
						$query = $wpdb->prepare( "SELECT * FROM $this->table_name WHERE auction_id = %d AND user_id <> %d ORDER by CAST(bid AS decimal(50,5)) DESC, date ASC LIMIT 1",$product_id,$first_bid->user_id);
					}
                    $second_bid = $wpdb->get_row( $query );
                    if($second_bid){
                        $bids[] = $second_bid;
                    }
                }
            }

            return $bids;
        }
        /**
         * @param $auction_id
         *
         * @return null|object
         */
        public function get_last_bid_user( $user_id, $auction_id ) {
            global $wpdb;

            $query   = $wpdb->prepare( "SELECT bid FROM $this->table_name WHERE user_id = %d AND auction_id = %d ORDER by date DESC LIMIT 1", $user_id, $auction_id );
            $results = $wpdb->get_var( $query );

            return $results;
        }

        /**
         * @param $product_id
         *
         * @return null|object
         */
        public function get_users( $product_id ) {
            global $wpdb;

            $query   = $wpdb->prepare( "SELECT DISTINCT  user_id FROM $this->table_name WHERE auction_id = %d ", $product_id );
            $results = $wpdb->get_results( $query );

            return $results;
        }

        /**
         * @param $product_id
         *
         * @return null|object
         */
        public function get_auctions_by_user( $user_id , $limit = false ) {
            global $wpdb;

            if ( $limit ) {
				$query   = $wpdb->prepare( "SELECT auction_id FROM $this->table_name WHERE user_id = %d GROUP by auction_id ORDER by date DESC LIMIT %d", $user_id, $limit);

			} else {
				$query   = $wpdb->prepare( "SELECT auction_id FROM $this->table_name WHERE user_id = %d GROUP by auction_id ORDER by date DESC", $user_id);
			}

            $results = $wpdb->get_results( $query );

            foreach ($results as &$valor) {
                $query   = $wpdb->prepare( "SELECT bid FROM $this->table_name WHERE auction_id = %d AND user_id = %d ORDER by CAST(bid AS decimal(50,5)) DESC, date ASC LIMIT 1", $valor->auction_id, $user_id );
                $result = $wpdb->get_var( $query );
                $valor->max_bid = $result;
            }

            return $results;
        }

        /**
         * @param $auction_id
         *
         * @return null|object
         */
        public function reshedule_auction($auction_id){
            global $wpdb;
            $query = $wpdb->prepare("DELETE FROM $this->table_name WHERE auction_id=%d",$auction_id);
            $results = $wpdb->get_results($query);
            return $results;
        }

        /**
         * delete customer bid
         * @param $auction_id, $user_id, $datetime
         *
         * @return null|object
         */
        public function delete_customer_bid($auction_id,$user_id,$datetime) {
            global $wpdb;
            $query = $wpdb->prepare("DELETE FROM $this->table_name WHERE auction_id=%d AND user_id=%d AND date =%s",$auction_id,$user_id,$datetime);
            $results = $wpdb->get_results($query);
            return $results;
        }
		/**
		 * delete all customer bids for a specific auction product
		 * @param $auction_id, $user_id
		 *
		 * @return null|object
		 */
        public function remove_customer_bids( $user_id, $auction_id ) {
			global $wpdb;
			$query = $wpdb->prepare("DELETE FROM $this->table_name WHERE auction_id=%d AND user_id=%d", $auction_id, $user_id );
			$results = $wpdb->get_results($query);
			return $results;
		}

        /**
         * @param $product_id
         *
         * @return null|object
         */
        public function get_auctions_by_user_export( $user_id ) {
            global $wpdb;

            $query   = $wpdb->prepare( "SELECT auction_id, bid FROM $this->table_name WHERE user_id = %d  ORDER by auction_id DESC", $user_id);
            $results = $wpdb->get_results( $query );

            return $results;
        }

		// ==== Fee database call === //

		/**
	     *  Get if user paid the fee for auction product.
	     *
	     * @param  int $user_id
	     * @param  int $auction_id
	     * @since  2.0.0
	     * @return null|object
	     */
	    public function get_user_fee_payment( $user_id, $auction_id ) {
		    global $wpdb;

		    $query   = $wpdb->prepare( "SELECT auction_id FROM $this->table_name_fee WHERE user_id = %d  AND auction_id = %d", $user_id, $auction_id);
		    $results = $wpdb->get_var( $query );

		    return $results;
	    }
		/**
		 *  Register fee on database
		 *
		 * @param  int $user_id
		 * @param  int $auction_id
		 * @param  DateTime $date
		 * @param  int $order_id
		 * @param  float $fee_amount
		 * @since  2.0.0
		 * @return null|object
		 */
	    public function register_fee( $user_id, $auction_id, $date, $order_id, $fee_amount ) {

			global $wpdb;

			$insert_query = "INSERT INTO $this->table_name_fee (`user_id`, `auction_id`, `date`, `order_id`, `fee_amount`) VALUES ('" . $user_id . "', '" . $auction_id . "', '" . $date . "' , '" . $order_id . "', '" . $fee_amount . "' )";
			$wpdb->query( $insert_query );

		}


		// ==== Whatchlist database call === //
		/**
		 *  Get auction products from whatchlist.
		 *
		 * @param  int $user_id
		 * @param  int $limit
		 * @since  2.0.0
		 * @return null|object
		 */
		public function get_whatchlist_product_by_user( $user_id, $limit = false ) {
			global $wpdb;

			if ( $limit ) {
				$query   = $wpdb->prepare( "SELECT auction_id FROM $this->table_watchlist WHERE user_id = %d GROUP by auction_id ORDER by dateadded DESC LIMIT %d", $user_id, $limit);

			} else {
				$query   = $wpdb->prepare( "SELECT auction_id FROM $this->table_watchlist WHERE user_id = %d GROUP by auction_id ORDER by dateadded DESC", $user_id);
			}

			$results = $wpdb->get_results( $query );

			foreach ($results as &$valor) {
				$query   = $wpdb->prepare( "SELECT bid FROM $this->table_name WHERE auction_id = %d AND user_id = %d ORDER by CAST(bid AS decimal(50,5)) DESC, date ASC LIMIT 1", $valor->auction_id, $user_id );
				$result = $wpdb->get_var( $query );
				$valor->max_bid = $result;
			}

			return $results;
		}

		/**
		 *  Get users that have the product in the whatchlist.
		 *
		 * @param  int $auction_id
		 * @since  2.0.0
		 * @return null|object
		 */

		public function get_users_count_product_on_watchlist( $auction_id ) {
			global $wpdb;

			$query   = $wpdb->prepare( "SELECT user_id FROM $this->table_watchlist WHERE auction_id = %d GROUP by user_id", $auction_id );
			$results = $wpdb->get_results( $query );

			return $results;

		}
		/**
		 *  Check if user has product in whatchlist
		 *
		 * @param  int $user_id
		 * @param  int $auction_id
		 * @since  2.0.0
		 * @return null|object
		 */
		public function is_product_in_watchlist( $auction_id, $user_id ) {
			global $wpdb;
			$query   = $wpdb->prepare( "SELECT user_id FROM $this->table_watchlist WHERE auction_id = %d AND user_id = %d GROUP by user_id", $auction_id, $user_id );

			$result = $wpdb->get_var( $query );

			return $result;

		}

		/**
		 *  Add product to the watchlist
		 *
		 * @param  int $user_id
		 * @param  int $auction_id
		 * @since  2.0.0
		 * @return boolean
		 */
		public function add_product_to_watchlist( $auction_id, $user_id ) {
			global $wpdb;
			$insert_query = "INSERT INTO $this->table_watchlist (`user_id`, `auction_id`) VALUES ('" . $user_id . "', '" . $auction_id . "' )";
			$wpdb->query( $insert_query );

			return true;

		}
		/**
		 *  Remove product to the watchlist
		 *
		 * @param  int $user_id
		 * @param  int $auction_id
		 * @since  2.0.0
		 * @return boolean
		 */
		public function remove_product_to_watchlist( $auction_id, $user_id ) {
			global $wpdb;
			$query = $wpdb->prepare("DELETE FROM $this->table_watchlist WHERE auction_id=%d AND user_id=%d",$auction_id, $user_id );
			$wpdb->query( $query );
			return true;
		}

    }
}