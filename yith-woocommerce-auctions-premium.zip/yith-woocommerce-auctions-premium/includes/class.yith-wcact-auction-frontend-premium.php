<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */
if ( !defined( 'YITH_WCACT_VERSION' ) ) {
    exit( 'Direct access forbidden.' );
}

/**
 *
 *
 * @class      YITH_Auctions_Frontend
 * @package    Yithemes
 * @since      Version 1.0.0
 * @author     Carlos Rodríguez <carlos.rodriguez@yithemes.com>
 *
 */
if ( !class_exists( 'YITH_Auction_Frontend_Premium' ) ) {
    /**
     * Class YITH_Auctions_Frontend
     *
     * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
     */
    class YITH_Auction_Frontend_Premium extends YITH_Auction_Frontend {

	    /**
	     * Main Popup Instance
	     *
	     * @var WC_Product_Auction
	     * @since 2.0
	     */
	    public $popup = null;
        /**
         * Construct
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         */
        public function __construct() {

			add_filter( 'woocommerce_catalog_orderby', array( $this, 'sort_auctions' ) );
			add_filter( 'woocommerce_get_catalog_ordering_args', array( $this, 'ordering_auction' ) );
			/* == Cart == */
			add_filter( 'woocommerce_get_cart_item_from_session', array( $this, 'get_cart_item_from_session' ), 10 );
			add_filter( 'woocommerce_add_cart_item', array( $this, 'add_cart_item' ), 10 );
			add_filter( 'woocommerce_add_cart_item_data', array( $this, 'add_cart_item_yith_auction_data' ), 10, 2 );
			add_action( 'pre_get_posts', array( $this, 'modify_query_loop' ) );
			add_action( 'woocommerce_checkout_order_processed', array( $this, 'finish_auction' ), 10, 2 );

			/*== Product Page == */
			add_filter( 'yith_wcact_before_form_add_to_cart', array( $this, 'check_closed_for_buy_now' ), 10, 2 );
			add_action( 'yith_wcact_in_to_form_add_to_cart', array( $this, 'print_auction_condition' ), 10 );
			add_action( 'yith_wcact_in_to_form_add_to_cart', array( $this, 'check_if_max_bid_and_reserve_price' ), 20 );
			add_action( 'yith_wcact_auction_before_set_bid', array( $this, 'add_auction_timeleft' ),10, 2 );
			add_action( 'yith_wcact_after_add_button_bid', array( $this, 'if_reserve_price' ) );
			add_action( 'yith_wcact_after_add_button_bid', array( $this, 'add_button_buy_now' ), 20 );
			add_filter( 'yith_wcact_actual_bid_add_value', array( $this, 'bid_value_step_for_plugin_buttons' ) );


			/* == Follower list == */
			add_action( 'yith_wcact_after_add_to_cart_form', array( $this, 'add_followers_form' ) );
			add_action( 'wp_loaded', array( $this, 'add_to_followers_list' ), 90 );
			/* == Watchlist feature ==*/
			add_action( 'yith_wcact_after_add_button_bid', array( $this, 'add_watchlist_button' ), 50 );
			add_action( 'yith_wcact_after_no_start_auction', array( $this,'add_watchlist_button' ), 50  );
			add_action( 'init', array( $this, 'add_to_watchlist_list' ) );
			add_action( 'init', array( $this, 'remove_from_watchlist' ) );
			add_action( 'init', array( $this, 'add_watchlist_notice' ) );


			//add_action( 'woocommerce_checkout_create_order_line_item', array( $this, 'update_order_item_data_for_auction_fee' ), 30, 3 );
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_custom_style' ), 99 );

			$this->popup = new YITH_WCACT_Popup();

			parent::__construct();
		}

        /**
         * Enqueue Scripts
         *
         * Register and enqueue scripts for Frontend
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0.9
         * @return void
         */
        public function enqueue_scripts() {
            global $post, $wp_locale;

			$product = isset( $post ) && !empty( $post ) ? wc_get_product( $post->ID ) : false ;
			$format_date = get_option( 'yith_wcact_general_date_format','j/n/Y' );
	        $format_time = get_option( 'yith_wcact_general_time_format', 'h:i:s' );

	        $format = $format_date.' '.$format_time;

            $date_params = array(
                'format'       => $format,
                'month'        => $wp_locale->month,
                'month_abbrev' => $wp_locale->month_abbrev,
                'meridiem'     => $wp_locale->meridiem,
                'show_in_customer_time' => apply_filters('yith_wcact_show_time_in_customer_time',true),
                'actual_bid_add_value' => apply_filters('yith_wcact_actual_bid_add_value',1),
            );
            wp_register_style( 'yith-wcact-frontend-css', YITH_WCACT_ASSETS_URL . 'css/frontend.css',array(),YITH_WCACT_VERSION );
            wp_register_style( 'yith-wcact-widget-css', YITH_WCACT_ASSETS_URL . 'css/yith-wcact-widget.css',array(),YITH_WCACT_VERSION  );


			/* === Script === */
            wp_register_script( 'yith-wcact-frontend-js-premium', YITH_WCACT_ASSETS_URL . 'js/frontend-premium.js', array( 'jquery', 'jquery-ui-datepicker', 'accounting' ), YITH_WCACT_VERSION, 'true' );

            //Localize scripts for ajax call
            wp_localize_script( 'yith-wcact-frontend-js-premium', 'object', array(
                'ajaxurl'                   => admin_url( 'admin-ajax.php' ),
                'live_auction_product_page' => 'yes' == get_option('yith_wcact_ajax_refresh_auction_product_page','no') ? (int)get_option( 'yith_wcact_settings_live_auction_product_page',0 ) * 1000 : 0,
                'add_bid'                   => wp_create_nonce( 'add-bid' ),
				'bid_empty_error'			=> esc_html__('Please insert a value for your bid.','yith-auctions-for-woocommerce'),
            ) );

            // localize script for date format
            wp_localize_script( 'yith-wcact-frontend-js-premium', 'date_params', $date_params );

            if ( apply_filters( 'yith_wcact_load_script_everywhere', false ) || is_shop() || is_archive() ) {
                /* === CSS === */
                wp_enqueue_style( 'yith-wcact-frontend-css' );

                /* === Script === */

                wp_enqueue_script( 'yith_wcact_frontend_shop_premium', YITH_WCACT_ASSETS_URL . 'js/fontend_shop-premium.js', array( 'jquery', 'jquery-ui-sortable' ), YITH_WCACT_VERSION, true );
                wp_localize_script( 'yith_wcact_frontend_shop_premium', 'object', array(
                    'ajaxurl' => admin_url( 'admin-ajax.php' ),
                    'add_bid' => wp_create_nonce( 'add-bid' ),
                ) );

                wp_localize_script( 'yith_wcact_frontend_shop_premium', 'date_params', $date_params );

            }

            if ( apply_filters( 'yith_wcact_load_script_widget_everywhere', false ) || ( is_active_widget( false, false, 'yith_woocommerce_auctions', true ) || is_active_widget( false, false, 'yith-wcact-auction-watchlist', true ) ) ) {
                /* === CSS === */
                wp_enqueue_style( 'yith-wcact-widget-css' );

				if( ! wp_script_is('yith_wcact_frontend_shop_premium' ) && ( !$product || ( $product && 'auction' != $product->get_type() ) ) ) {
					wp_enqueue_script( 'yith_wcact_frontend_shop_premium', YITH_WCACT_ASSETS_URL . 'js/fontend_shop-premium.js', array( 'jquery', 'jquery-ui-sortable' ), YITH_WCACT_VERSION, true );
					wp_localize_script( 'yith_wcact_frontend_shop_premium', 'object', array(
						'ajaxurl' => admin_url( 'admin-ajax.php' ),
						'add_bid' => wp_create_nonce( 'add-bid' ),
					) );

					wp_localize_script( 'yith_wcact_frontend_shop_premium', 'date_params', $date_params );
					wp_enqueue_style( 'yith-wcact-frontend-css' );

				}

            }

            if ( is_product() ) {
                $product = wc_get_product( $post->ID );
                if ( $product && 'auction' == $product->get_type() ) {
					/* === CSS === */
                    wp_enqueue_style( 'yith-wcact-frontend-css' );
                    wp_enqueue_style( 'dashicons' );
                    /* === Script === */
                    wp_enqueue_script( 'yith-wcact-frontend-js-premium' );
                }
            }

            $endpoint = YITH_Auctions()->endpoint;
            if ( 'my-auction' == $endpoint->get_current_endpoint() ) {
                wp_enqueue_script( 'yith_wcact_frontend_endpoint', YITH_WCACT_ASSETS_URL . '/js/frontend-endpoint-premium.js', array( 'jquery', 'jquery-ui-sortable' ), YITH_WCACT_VERSION, true );
                wp_localize_script( 'yith_wcact_frontend_endpoint', 'object', array(
                    'ajaxurl'    => admin_url( 'admin-ajax.php' ),
                    'time_check' => 'yes' == get_option('yith_wcact_ajax_refresh_auction_my_acutions_page','no') ? get_option( 'yith_wcact_settings_live_auction_my_auctions',0 ) * 1000 : 0,
                    'add_bid'    => wp_create_nonce( 'add-bid' ),
                ) );
                wp_enqueue_style( 'yith-wcact-frontend-css' );

			}

            do_action( 'yith_wcact_enqueue_fontend_scripts' );

        }

	    /**
	     * Enqueue Custom Style
	     *
	     * Enqueue style dynamic generated by the plugin
	     *
	     * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
	     * @since 2.0.0
	     * @return void
	     */
         public function enqueue_custom_style() {

	         $custom_css = $this->_build_custom_css();
	         if( $custom_css ) {
		         $handle = wp_style_is( 'yith-wcact-frontend-css' ) ? 'yith-wcact-frontend-css' : false;

		         if( $handle ) {

			         wp_add_inline_style( $handle, $custom_css );
                 }
	         }
         }

        /**
         * Sort Auction
         *
         * ​Add to WooCommerce sorting select (in shop page) Sort auctions
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         * @return void
         */
        public function sort_auctions( $tabs ) {
            $sort = array(
                'auction_asc'  => esc_html__( 'Sort auctions by end date (asc)', 'yith-auctions-for-woocommerce' ),
                'auction_desc' => esc_html__( 'Sort auctions by end date (desc)', 'yith-auctions-for-woocommerce' ),
            );
            $tabs = array_merge( $tabs, $sort );

            return $tabs;
        }

        /**
         * Sort Auction
         *
         * ​Add to WooCommerce sorting select (in shop page) Sort auctions
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         * @return array
         */
        public function ordering_auction( $args ) {
            $orderby_value = isset( $_GET[ 'orderby' ] ) ? wc_clean( $_GET[ 'orderby' ] ) : apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby' ) );

            if ( $orderby_value == 'auction_asc' ) {
                $args[ 'orderby' ]  = 'meta_value';
                $args[ 'order' ]    = 'ASC';
                $args[ 'meta_key' ] = '_yith_auction_to';
            }

            if ( $orderby_value == 'auction_desc' ) {
                $args[ 'orderby' ]  = 'meta_value';
                $args[ 'order' ]    = 'DESC';
                $args[ 'meta_key' ] = '_yith_auction_to';
            }
            return apply_filters('yith_wcact_ordering_auction',$args,$orderby_value);
        }

        /**
         * Auction end
         *
         * ​Show the Auction end or show the auction start if the auction start after today's date (in shop page)
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         * @return void
         */
        public function auction_end_start() {
            global $product;
            $product = apply_filters( 'yith_wcact_get_auction_product', $product );

            if ( $product && 'auction' == $product->get_type() ) {

            	if ( $product->is_closed()  || $product->get_is_closed_by_buy_now() ) {
					echo '<div class=" auction_end_start ywcact-auction-ended-loop" >';
            		echo '<span class="ywcact_auction_end_start_label">' . esc_html__('Auction ended','yith-auctions-for-woocommerce') . '</span>';
					echo '</div>';

				} else {

					$auction_start = $product->get_start_date();
					$auction_end   = $product->get_end_date();
					$date          = strtotime( 'now' );

					$time_zone = get_option( 'yith_wcact_general_time_zone', '' );


					if ( $date < $auction_start ) {

						$this->timeleft_loop( $product, $auction_end, $date );

						echo '<div class="auction_end_start">';

						echo '<span class="ywcact_auction_end_start_label">' . sprintf( esc_html_x( 'Auction start:', 'Auction ends: 10 Jan 2016 10:00', 'yith-auctions-for-woocommerce' ) ) . '</span>';
						echo '<span class="date_auction" data-yith-product="' . $product->get_id() . '" data-yith-auction-time="' . $auction_start . '">' . '</span><span>' . $time_zone . '</span>';
						echo '</div>';


					} else {
						if ( ! empty( $auction_end ) && ! $product->is_closed() && ! $product->get_is_closed_by_buy_now() ) {

							$this->timeleft_loop( $product, $auction_end, $date, 'yith_end_type' );

							echo '<div class="auction_end_start">';
							echo '<span class="ywcact_auction_end_start_label">' . sprintf( esc_html_x( 'Auction ends:', 'Auction ends: 10 Jan 2016 10:00', 'yith-auctions-for-woocommerce' ) ) . '</span>';
							echo '<span class="date_auction" data-yith-product="' . $product->get_id() . '" data-yith-auction-time="' . $auction_end . '">' . '</span><span>' . $time_zone . '</span>';
							echo '</div>';

						}

					}
				}

                do_action('yith_wcact_auction_end_start', $product );
            }
        }

        /**
         * Change text button
         *
         * Change text Auction button (in shop page)
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         */
        public function change_button_auction_shop( $text, $product ) {
            $product = apply_filters( 'yith_wcact_get_auction_product', $product );

			if ( 'auction' == $product->get_type() ) {

				if ( ! $product->is_closed() && ! $product->get_is_closed_by_buy_now() ) {
					$text = apply_filters( 'yith_wcact_change_button_auction_shop_text', esc_html__( 'Bid now', 'yith-auctions-for-woocommerce' ), $product, $text );
				} else {
					$text = apply_filters( 'yith_wcact_change_button_auction_shop_text', esc_html__( 'View', 'yith-auctions-for-woocommerce' ), $product, $text );
				}
			}

            return $text;
        }


        /**
         * Badge Shop
         *
         * Add a badge if product type is: auction (in shop page)
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         * @return void
         */

        public function auction_badge_shop() {
            global $product;

            if ( $product && 'auction' == $product->get_type() && 'yes' == get_option( 'yith_wcact_show_auction_badge', 'yes' ) ) {

                $img = get_option( 'yith_wcact_appearance_button' );
	            $img = ( $img ) ? $img : YITH_WCACT_ASSETS_URL . '/images/badge.svg';

	            echo '<span class="yith-wcact-aution-badge"><img src="' . $img . '"></span>';

            }
        }

        /**
         *  Add cart item data
         *
         *  Create a new array yith_auction_data in $cart_item_data
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         * @return $cart_tem_data
         */
        public function add_cart_item_yith_auction_data( $cart_item_data, $product_id ) {

            $product_id   = apply_filters( 'yith_wcact_auction_product_id', $product_id );
            $terms        = get_the_terms( $product_id, 'product_type' );
            $product_type = !empty( $terms ) && isset( current( $terms )->name ) ? sanitize_title( current( $terms )->name ) : 'simple';
            if ( 'auction' === $product_type && !isset( $cart_item_data[ 'yith_auction_data' ] ) ) {
                $cart_item_data[ 'yith_auction_data' ] = array(
                    'buy-now' => true
                );
            }

            return $cart_item_data;
        }

        /**
         *  Change price in cart item
         *
         *  If the product_type = 'auction' and click in buy_now change price to buy_now_price
		 *  This code also check if the product is a fee product, change the price.
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         * @return $cart_tem_data
         */
        public function add_cart_item( $cart_item_data ) {
        	// Check if add buy now product
            if ( isset( $cart_item_data[ 'yith_auction_data' ] ) && isset( $cart_item_data[ 'yith_auction_data' ][ 'buy-now' ] ) ) {
                $product = apply_filters('yith_wcact_get_auction_product',$cart_item_data[ 'data' ]);
                $buy_now_price = $product->get_buy_now();
                if ( !$buy_now_price) {
                    wc_add_notice( esc_html__( 'You cannot purchase this product because it is an Auction!', 'yith-auctions-for-woocommerce' ), 'error' );

                    return false;
                }

                $product->set_price( $buy_now_price );
                $cart_item_data[ 'data' ] = $product;
            }

            // Check fee product section
			if ( isset( $cart_item_data[ 'yith_wcact_if_fee_product' ] ) && isset( $cart_item_data[ 'yith_wcact_fee_value' ] ) ) {
				$product = apply_filters('yith_wcact_get_auction_product',$cart_item_data[ 'data' ]);
				$product->set_price( $cart_item_data[ 'yith_wcact_fee_value' ] );
				$cart_item_data[ 'data' ] = $product;

			}

            return $cart_item_data;
        }

        /**
         *  Load cart from session
         *
         *  Change auction or fee product price on session.
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         * @return $cart_tem_data
         */

        public function get_cart_item_from_session( $session_data ) {

            if ( isset( $session_data[ 'yith_auction_data' ] ) && isset( $session_data[ 'yith_auction_data' ][ 'buy-now' ] ) ) {
                $product       = $session_data[ 'data' ];
                $buy_now_price = $product->get_buy_now();
                $product->set_price( $buy_now_price );
                $session_data[ 'data' ] = $product;
            }

			if ( isset( $session_data[ 'yith_wcact_if_fee_product' ] ) && isset( $session_data[ 'yith_wcact_fee_value' ] ) ) {
				$product = $session_data[ 'data' ];
				$product->set_price( $session_data[ 'yith_wcact_fee_value' ] );
				$cart_item_data[ 'data' ] = $product;

			}


            return $session_data;

        }

        public function modify_query_loop( $q ) {

            $metaqueries = array();
           if ( $q->is_main_query() && isset( $q->query[ 'post_type' ] ) && 'product' === $q->query[ 'post_type' ] && is_shop() || apply_filters( 'yith_wcact_query_loop', function_exists('is_archive') ? is_archive() : false, $q ) ) {

                if ( 'no' == get_option( 'yith_wcact_show_auctions_shop_page' ) ) {
                    $taxquery = $q->get( 'tax_query' );
                    if ( is_array( $taxquery ) ) {
                        $taxquery[] = array(
                            'taxonomy' => 'product_type',
                            'field'    => 'slug',
                            'terms'    => 'auction',
                            'operator' => 'NOT IN'
                        );
	                    $q->set( 'tax_query', $taxquery );
                    }


                } else {

                    $metaquery = $q->get( 'meta_query' );

                    if ( ( 'yes' == get_option( 'yith_wcact_hide_auctions_out_of_stock' ) ) ) {
                        $metaquery = $q->get( 'meta_query' );
                        if ( is_array( $metaquery ) ) {
                            $metaquery1 = array(
                                'relation' => 'OR',
                                array(
                                    'key'     => '_yith_auction_to',
                                    'compare' => 'NOT EXISTS'
                                ),
                                array(
                                    'key'     => '_stock_status',
                                    'value'   => 'outofstock',
                                    'compare' => '!='
                                ) );

                            $metaqueries[] = $metaquery1;
                        }


                    }


                    if (('yes' == get_option('yith_wcact_hide_auctions_closed'))) {
                        if (is_array($metaquery)) {

                            $metaquery1 = array(
                                'relation' => 'OR',
                                array(
                                    'key' => '_yith_auction_to',
                                    'compare' => 'NOT EXISTS'
                                ),
                                array(
                                    'key' => '_yith_auction_to',
                                    'value' => strtotime('now'),
                                    'compare' => '>='
                                )
                            );
                            $metaqueries[] = $metaquery1;
                        }

                    }
                    if (('yes' == get_option('yith_wcact_hide_auctions_not_started'))) {
                        if (is_array($metaquery)) {
                            $metaquery1 = array(
                                'relation' => 'OR',
                                array(
                                    'key' => '_yith_auction_for',
                                    'compare' => 'NOT EXISTS'
                                ),
                                array(
                                    'key' => '_yith_auction_for',
                                    'value' => strtotime('now'),
                                    'compare' => '<'
                                )
                            );
                            $metaqueries[] = $metaquery1;
                        }

                    }

                    $andqueries = '';
                    foreach ($metaqueries as $metaquery ) {

                        if( empty($andqueries) ) {

                            $andqueries = $metaquery;

                        }else {

                            $andqueries = array(
                                'relation' => 'AND',
                                $andqueries,$metaquery
                            );
                        }
                    }


                    if( $andqueries ) {
                        $metaquery = $andqueries;
                    }
                    $q->set( 'meta_query', $metaquery );
                }

            }


        }

        /**
         *  Finish auction
         *
         *  If the product_type = 'auction', //The auction end because the user click in buy_now and place order
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         */
        public function finish_auction( $order_id, $post ) {
            $order = wc_get_order( $order_id );
            foreach ( $order->get_items() as $item ) {
                $_product = $item->get_product();
                if ( $_product && 'auction' == $_product->get_type() ) {
                    $_product->set_stock_status( 'outofstock' );
                    if ( !$_product->is_closed() ) {
                        $_product->set_is_closed_by_buy_now(true);
                        $_product->save();
                    }
                }
            }
        }

        /**
         *  yith_check_closed_for_buy_now
         *  Check if auction is closed for buy now
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         */
        public function check_closed_for_buy_now( $status, $product ) {
            $product = apply_filters( 'yith_wcact_get_auction_product', $product );

            if ( $product->get_is_closed_by_buy_now() ) {
                return false;
            }

            return $status;
        }

        /**
         *  Show auction info
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0.14
         */
        public function check_if_max_bid_and_reserve_price( $product ) {
            $args = array(
                'product' => $product,
                'currency' => get_woocommerce_currency()
            );
            wc_get_template( 'max-bidder.php', $args, '', YITH_WCACT_TEMPLATE_PATH . 'frontend/' );
        }

        /**
         *  Show auction timeleft on product page
         * @param WC_Product $product
		 * @param string $auction_status
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0.14
         */
        public function add_auction_timeleft( $product, $auction_status = 'started' ) {

				$auction_date = $product->is_start() ? $product->get_end_date() : $product->get_start_date();
	            $auction_finish = ( $datetime = $auction_date ) ? $datetime : null;
	            $date           = strtotime( 'now' );

	            $countdown_style = get_option('yith_wcact_countdown_style','default');

	            $countdown_blocks = ( 'big-blocks' == $countdown_style ) ? 'yith-wcact-blocks' : '';

                $yith_wcact_class = 'yith-wcact-timeleft-'.$countdown_style.' yith-wcact-timeleft-product-page';


		        $time_end_auction  = $auction_finish;
		        $color_number      = get_option( 'yith_wcact_customization_countdown_color_numbers',24 );
		        $color_unit        = get_option( 'yith_wcact_customization_countdown_color_unit','hours' );
		        $time_change_color = strtotime( ( sprintf( "-%d %s", $color_number, $color_unit ) ), (int)$time_end_auction );

		        if ( $date > $time_change_color  ) {

			        $yith_wcact_class .= ' yith-wcact-countdown-last-minute';
			        $time_change_color = 0;
		        }

	            $args = apply_filters( 'yith_wcact_add_auction_timeleft_args', array(
		            'product'          => $product,
		            'product_id'       => $product->get_id(),
		            'auction_finish'   => $auction_finish,
		            'date'             => $date,
		            'last_minute'       => isset( $time_change_color ) ? $auction_finish - $time_change_color : 0,
		            'total'            => $auction_finish - $date,
		            'yith_wcact_class' => isset( $yith_wcact_class ) ? $yith_wcact_class : 'yith-wcact-timeleft-default',
					'yith_wcact_block' => isset( $countdown_blocks ) ? $countdown_blocks : '',
	            ), $product );


		        $show_countdown = ( 'yes' == get_option( 'yith_wcact_show_general_countdown','yes') );
		        $show_end_date = ( 'yes'  == get_option( 'yith_wcact_show_end_date_auctions', 'yes' ) );

		        if( $show_countdown || $show_end_date  ) {
					?>
					<div class="yith-wcact-container-timeleft <?php echo 'yith-wcact-container-timeleft-' . $countdown_style; ?>">

						<?php
						if ( $show_countdown ) {

							?>
							<p for="yith_time_left" class="ywcact-time-left"><?php 'started' == $auction_status ? esc_html_e( 'Time left:', 'yith-auctions-for-woocommerce' ) : esc_html_e('Time left to start auction:', 'yith-auctions-for-woocommerce'); ?></p>

							<?php

							wc_get_template( 'auction-timeleft.php', $args, '', YITH_WCACT_TEMPLATE_PATH . 'frontend/' );

						}

						if ( $show_end_date && 'started' == $auction_status ) {

							wc_get_template( 'auction-end.php', $args, '', YITH_WCACT_TEMPLATE_PATH . 'frontend/' );
						}

						?>
					</div>

					<?php
				}
        }

        /**
         *  Show reserve price and overtime info
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         */
        public function if_reserve_price( $product ) {
            $args = array(
                'product' => $product
            );
            wc_get_template( 'reserve_price_and_overtime.php', $args, '', YITH_WCACT_TEMPLATE_PATH . 'frontend/' );
        }

        /**
         *  Add buy now button
         *
         * @param WC_Product_Auction $product
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         */
        public function add_button_buy_now( $product ) {

            $buy_now_onoff =  yith_wcact_field_onoff_value('buy_now_onoff','buy_now', $product );
            $buy_now = $product->get_buy_now();


            if ( ( 'reverse' !== $product->get_auction_type() && 'yes' == $buy_now_onoff && !!$buy_now && $buy_now > 0 && apply_filters( 'yith_wcact_show_buy_now_button', true, $product,$buy_now ) ) || apply_filters('yith_wcact_show_always_buy_now_button', false, $product, $buy_now) ) {
                $display = true;
                if ('yes' == get_option('yith_wcact_settings_hide_buy_now_price_exceed','no') && $product->get_price() >= $buy_now  ) {
                    $display = false;
                } elseif ( $display && 'yes' == get_option('yith_wcact_settings_hide_buy_now_after_first_bid') && YITH_Auctions()->bids->get_max_bid( $product->get_id() ) ) {
                    $display = false;
                }

                if ( $display ) {
	                ?>
                    <input type="hidden" name="add-to-cart"
                           value="<?php echo esc_attr( $product->get_id() ); ?>"/>
                    <button type="submit"
                            class="auction_add_to_cart_button ywcact-auction-buy-now-button button alt"
                            id="yith-wcact-auction-add-to-cart-button">
		                <?php echo sprintf( esc_html_x( 'Buy now for %s',
			                'Purchase it now for $ 50.00',
			                'yith-auctions-for-woocommerce' ),
			                wc_price( apply_filters( 'yith_wcact_get_price_for_customers_buy_now',
				                $buy_now, $product ) ) ) ?>
                    </button>
	                <?php
                }
            }
        }

        /**
         *  Display message on product page when auction finnish
         *
         * @param WC_Product_Auction $product
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         */

        public function auction_end( $product ) {
            $instance = YITH_Auctions()->bids;
            $max_bid  = $instance->get_max_bid( $product->get_id() );
            $show_reason = 'yes' == get_option('yith_wcact_how_auction_ended','yes') ? true : false ;
            if ( !( $product->has_reserve_price() && $product->get_price() < $product->get_reserve_price() ) && $max_bid && $product->is_in_stock() ) { //Admin email{ //Then we send the email to the winner with the button for paying the order.

                $current_user = wp_get_current_user();
                if ( $current_user->ID == $max_bid->user_id ) {
					$stripe_checked = false;

					if( defined( 'YITH_WCSTRIPE_PREMIUM' ) && 'yes' == get_option('yith_wcact_verify_payment_method','no') ) {
						$tokens = WC_Payment_Tokens::get_customer_tokens($current_user->ID );
						if( empty( $tokens ) ) {
							$stripe_checked = true;
						}
					}


					$winner_message = ywcact_generate_content_winner( $product, $current_user );

					$img = get_option( 'yith_wcact_appearance_button',  YITH_WCACT_ASSETS_URL . '/images/badge.svg'  );

					if( 'yes' == get_option('yith_wcact_auction_winner_show_winner_badge', 'no' ) ) {

						$img = get_option( 'yith_wcact_winner_badge_custom', YITH_WCACT_ASSETS_URL . '/images/icon/winner-logo.svg' );
					}

                    ?>
                    <div class="ywcact-congratulations-winner-auction-section">
                        <div class="ywcact-congratulation-message-container">
                             <div class="ywcact-congratulation-message-header">

								 <span class="ywcact-congratulation-title"><img src="<?php echo $img; ?>"><span class="ywcact-congratulation-title-message"><?php echo apply_filters('yith_wcact_congratulation_message_title', sprintf( esc_html__( 'Congratulations %s!', 'yith-auctions-for-woocommerce' ), $current_user->data->display_name ), $product, $current_user->data->display_name ); ?></span></span>
                             </div>
                            <div class="ywcact-congratulation-message-content">
                            	<?php echo apply_filters('the_content', $winner_message ); ?>
							</div>
                        </div>

						<?php if( ! $stripe_checked ) { ?>
                        <form class="cart" method="get" enctype='multipart/form-data'>
                            <input type="hidden" name="yith-wcact-pay-won-auction" value="<?php echo esc_attr( $product->get_id() ); ?>"/>
                            <?php

                            if ( !$product->get_auction_paid_order() && ( 'yes' == get_option( 'yith_wcact_settings_tab_auction_show_button_pay_now' ) ) || apply_filters('yith_wcact_show_buttons_auction_end', false) ) {
                                ?>

                                <?php
                                if ( 'yes' == get_option( 'yith_wcact_settings_tab_auction_show_add_to_cart_in_auction_product' ) ) {

                                    ?>
                                    <button type="submit" class="auction_add_to_cart_button ywcact-auction-buy-now-button button alt"
                                            id="yith-wcact-auction-won-auction">
                                        <?php echo sprintf( esc_html__( 'Add to cart', 'yith-auctions-for-woocommerce' ) ); ?>
                                    </button>
                                    <?php
                                } else {
                                    ?>
                                    <button type="submit" class="auction_add_to_cart_button ywcact-auction-buy-now-button button alt"
                                            id="yith-wcact-auction-won-auction">
                                        <?php echo sprintf( esc_html__( 'Pay now', 'yith-auctions-for-woocommerce' ) ); ?>
                                    </button>
                                    <?php
                                }
                            }
                            ?>
                        </form>
						<?php } else {

							$payment_method_url = yith_wcact_get_payment_method_url();

							?>
							<div class="ywcact-add-yith-wcstripe-message">

								<p><?php echo sprintf( __( 'You need to add at least one credit card on <a href="%s" target="_blank">%2s</a> section in order to pay for this product.', 'yith-auctions-for-woocommerce' ), $payment_method_url, 'Payment method' ) ?></p>
							</div>
							<?php
						} ?>
                    </div>
                    <?php
                } else if ( $show_reason ) {

                    if ( $product->get_is_closed_by_buy_now() ) {

	                    ?>
                        <div id="yith_auction_end_product_page">
                            <h2><?php echo apply_filters('yith_wcact_closed_buy_now_message', esc_html__( 'This auction is ended to \'Buy Now\'',
				                    'yith-auctions-for-woocommerce' )); ?></h2>
                        </div>
	                    <?php

                    } else {

	                    ?>
                        <div id="yith_auction_end_product_page">
                            <h2><?php esc_html_e( 'This auction is ended',
				                    'yith-auctions-for-woocommerce' ) ?></h2>
                        </div>
	                    <?php
                    }
                }
            } else if ( $show_reason ) {

	            if ( $product->get_is_closed_by_buy_now() ) {

		            ?>
                    <div id="yith_auction_end_product_page">
                        <h2><?php echo apply_filters('yith_wcact_closed_buy_now_message', esc_html__( 'This auction is ended to \'Buy Now\'',
					            'yith-auctions-for-woocommerce' )); ?></h2>
                    </div>
		            <?php

	            } else {

		            ?>
                    <div id="yith_auction_end_product_page">
                        <h2><?php esc_html_e( 'This auction is ended',
					            'yith-auctions-for-woocommerce' ) ?></h2>
                    </div>
		            <?php
	            }
                do_action( 'yith_wcact_auction_auction_reserve_price', $product, $max_bid );

            }

			if ( apply_filters( 'yith_wcact_display_other_auctions', true, $product ) ) {
				echo do_shortcode( '[yith_wcact_other_auctions]' );
			}

            do_action( 'yith_wcact_after_auction_end', $product, $max_bid );
        }

        /**
         *  Show form to subscribe to this auction product
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         */
        public function add_followers_form( $product ) {

            if ( 'yes' == get_option( 'yith_wcact_settings_tab_auction_allow_subscribe' ) ) {
                $display_followers_form = true;
                $current_user_id   = get_current_user_id();
                if ( $current_user_id ) {
                    $customer = get_userdata( $current_user_id );
                    if ( $product->is_in_followers_list( $customer->data->user_email ) ) {
						$display_followers_form = false;
                    }
                }
                if ( apply_filters( 'yith_wcact_display_watchlist', $display_followers_form ) ) {
                    ?>
                    <div class="yith-wcact-watchlist-button">
                        <form class="yith-wcact-watchlist" method="post" enctype='multipart/form-data'>
							<p><?php esc_html_e( 'Follow this auction', 'yith-auctions-for-woocommerce' ); ?></p>
                            <div class="yith-wcact-watchlist-button">
                                <input type="hidden" name="yith-wcact-auction-id" value="<?php echo esc_attr( $product->get_id() ); ?>"/>
                                <p><?php apply_filters( 'yith_wcact_follow_auction_message', esc_html_e( 'Leave your email and we will let you know when the auction is about to end', 'yith-auctions-for-woocommerce' ) ); ?></p>
                                <input type="email" name="yith-wcact-watchlist-input-email" id="yith-wcact-watchlist-email" value="<?php echo ( $current_user_id ) ? $customer->data->user_email : ''; ?>"
                                       placeholder="<?php esc_html_e( 'Enter your email', 'yith-auctions-for-woocommerce' ) ?>">
                                <input type="submit" class="button button-primary yith-wcact-watchlist"
                                       value="<?php esc_html_e( 'Stay updated', 'yith-auctions-for-woocommerce' ); ?>">
                            </div>
                        </form>
                    </div>
                    <?php
                }
            }

        }

        /**
         *  Validate email and insert into followers product list
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
         * @since 1.0
         */
        public function add_to_followers_list() {
            if ( isset( $_REQUEST[ 'yith-wcact-watchlist-input-email' ] ) ) {
                $email = $_REQUEST[ 'yith-wcact-watchlist-input-email' ];
                if ( 0 == strlen( $email ) ) {
                    wc_add_notice( sprintf( esc_html__( 'The required email field is empty.',
                                                'yith-auctions-for-woocommerce' ) ), 'error' );


                } elseif ( !filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {
                    wc_add_notice( sprintf( esc_html__( 'The format of the email address entered for the followers list is not correct.',
                                                'yith-auctions-for-woocommerce' ) ), 'error' );

                } else {
                    $product_id = $_REQUEST[ 'yith-wcact-auction-id' ];
                    $product    = wc_get_product( $product_id );
                    if ( !$product->is_in_followers_list( $email ) ) {
                        $product->add_user_in_followers_list( $email );
                        wc_add_notice( sprintf( esc_html__( 'Your email "%s" was successfully added to the followers list.', 'yith-auctions-for-woocommerce' ),
                                                $email ), 'success' );
                    } else {
                        if ( apply_filters( 'yith_wcact_display_watchlist', false ) ) {
                            wc_add_notice( sprintf( esc_html__( 'Your email "%s" is already in the followers list.', 'yith-auctions-for-woocommerce' ),
                                                    $email ), 'error' );
                        }
                    }
                }
            }
        }
	    /**
	     *  Print timeleft on loop
	     *
	     * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
	     * @since 2.0
	     */
        public function timeleft_loop( $product,$auction_end,$date,$type='' ) {

	        $show_auction_on_loop = get_option('yith_wcact_show_countdown_in_loop','no');
	        $auction_date = $product->is_start() ? $product->get_end_date() : $product->get_start_date();

	        if( apply_filters( 'yith_wcact_timeleft_loop', 'yes' == $show_auction_on_loop, $product ) ) {

	            if( $type ) {

		            $time_end_auction  = $auction_end;
		            $color_number      = get_option( 'yith_wcact_customization_countdown_color_numbers',24 );
		            $color_unit        = get_option( 'yith_wcact_customization_countdown_color_unit','hours' );
		            $time_change_color = strtotime( ( sprintf( "-%d %s", $color_number, $color_unit ) ), (int)$time_end_auction );

		            if ( $date > $time_change_color  ) {

			            $yith_wcact_class = 'yith-wcact-timeleft-compact yith-wcact-countdown-last-minute';
			            $time_change_color = 0;
                    }
                }

		        $args = array(
			        'product'           => $product,
			        'auction_finish'    => $auction_end,
			        'date'              => $date,
			        'last_minute'       => isset( $time_change_color ) ? $auction_end - $time_change_color  : 0,
			        'total'             => $auction_date - $date,
			        'yith_wcact_class'  => isset( $yith_wcact_class ) ? $yith_wcact_class : 'yith-wcact-timeleft-compact',
					'yith_wcact_block' => isset( $countdown_blocks ) ? $countdown_blocks : '',

				);
                ?>
                <div class="yith-wcact-timeleft-loop">
                <?php
		            wc_get_template( 'auction-timeleft.php', $args, '', YITH_WCACT_TEMPLATE_PATH . 'frontend/' );
		        ?>
                </div>
		        <?php
	        }
        }

	    /**
	     * Generate CSS code to append to each page, to apply custom style to auction timeleft
	     *
	     * @param $rules array Array of additional rules to add to default ones
	     * @return string Generated CSS code
	     */
	    protected function _build_custom_css( $rules = array() ){

		    $generated_style_code = '';

		    $countdown_color = get_option('yith_wcact_countdown_color',array());

		    if( empty( $countdown_color ) ) {
				$countdown_color['section'] = '#f5f5f5';
			}

		    if ( is_product() && is_array( $countdown_color ) && !empty( $countdown_color ) ) {

		    	$color_section = isset( $countdown_color['section'] ) && !empty( $countdown_color['section'] ) ? $countdown_color['section'] : '#f5f5f5';
				$color_blocks = isset( $countdown_color['blocks'] ) && !empty( $countdown_color['blocks'] ) ? $countdown_color['blocks'] : '#ffffff';
				$color_text = isset( $countdown_color['text'] ) && !empty( $countdown_color['text'] ) ? $countdown_color['text'] : '';

                $generated_style_code.= '
                
                            .yith-wcact-time-left-main{ background-color:'.$color_section.';}
                            
                            .yith-wcact-timeleft.yith-wcact-blocks { background-color:'.$color_blocks.';}
                            
                            .yith-wcact-timer-auction  { color:'.$color_text.';}
                            
                            ';
            }

		    if ( $countdown_finalize_color = get_option('yith_wcact_customization_countdown_color_style')) {
                $generated_style_code.= '.yith-wcact-time-left-main .yith-wcact-countdown-last-minute { color:'.$countdown_finalize_color.';}
                                         .yith-wcact-timeleft-loop .yith-wcact-countdown-last-minute { color:'.$countdown_finalize_color.';}
                ';

            }

		    return apply_filters('yith_wcact_build_custom_css_rules',$generated_style_code,$countdown_color);

	    }
		/**
		 *  Print Auction condition
		 *
		 * @param WC_Product $product
		 *
		 * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
		 * @since 2.0
		 */
	    public function print_auction_condition( $product ) {

	    	if ( $product && 'auction' == $product->get_type() && 'yes' == get_option( 'yith_wcact_show_item_condition', 'no' ) && $condition = $product->get_item_condition() ) {
				/* translators: %1$s is replaced with the string of item conditions provided by admin */
	    		?>
					<div class="yith-wcact-item-condition">
						<?php echo sprintf( esc_html__( 'Condition: %1$s','yith-auctions-for-woocommerce' ), $condition  )  ?>
					</div>
				<?php

			}


		}
		/**
		 *  Print watchlist button
		 *
		 * @param WC_Product $product
		 *
		 * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
		 * @since 2.0
		 */
		public function add_watchlist_button( $product ) {
			if ( $product && 'auction' == $product->get_type() && apply_filters('yith_wcact_show_watchlist_button_on_product', 'yes' == get_option( 'yith_wcact_settings_enable_watchlist', 'no' ), $product ) ) {

				?>
				<div class="ywcact-add-to-watchlist-container">
				<?php

					echo do_shortcode( "[yith_wcact_add_to_watchlist]" );

				?>
				</div>
				<?php

			}
		}
		/**
		 *  Add product to watchlist
		 *
		 * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
		 * @since 2.0
		 */
		public function add_to_watchlist_list() {

			if ( isset( $_GET['add_to_watchlist'] ) && isset( $_GET['user_id'] ) &&  apply_filters('yith_wcact_show_watchlist_button_on_product', 'yes' == get_option( 'yith_wcact_settings_enable_watchlist', 'no' ) ) ) {
				$product_id = $_GET[ 'add_to_watchlist' ];
				$user_id = $_GET['user_id'];
				$product    = wc_get_product( $product_id );
				$current_user_id = get_current_user_id();

				$user_id = $user_id == $current_user_id ? $user_id : $current_user_id;

				if( $product && 'auction' == $product->get_type() ) {
					$instance           = YITH_Auctions()->bids;
					$product_in_watchlist = $instance->is_product_in_watchlist( $product_id, $user_id );

					if( ! $product_in_watchlist ) {
						$added = $instance->add_product_to_watchlist( $product_id, $user_id );

						if( $added ) {
							wc_add_notice( sprintf( esc_html__( 'Product "%s" was successfully added to your watchlist.', 'yith-auctions-for-woocommerce' ),
													$product->get_name() ), 'success' );
						}
					}

				}

			}
		}

		/**
		 *  Remove prdoduct to watchlist
		 *
		 * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
		 * @since 2.0
		 */
		public function remove_from_watchlist() {

			if ( isset( $_GET['remove_from_watchlist'] ) && isset( $_GET['user_id'] ) &&  apply_filters('yith_wcact_show_watchlist_button_on_product', 'yes' == get_option( 'yith_wcact_settings_enable_watchlist', 'no' ) ) ) {
				$product_id = $_GET[ 'remove_from_watchlist' ];
				$user_id = $_GET['user_id'];
				$product    = wc_get_product( $product_id );
				$current_user_id = get_current_user_id();

				$user_id = $user_id == $current_user_id ? $user_id : $current_user_id;

				if( $product && 'auction' == $product->get_type() ) {
					$instance           = YITH_Auctions()->bids;
					$product_in_watchlist = $instance->is_product_in_watchlist( $product_id, $user_id );

					if( $product_in_watchlist ) {
						$removed = $instance->remove_product_to_watchlist( $product_id, $user_id );

						if( $removed ) {
							wc_add_notice( sprintf( esc_html__( 'Product "%s" was successfully removed from your watchlist.', 'yith-auctions-for-woocommerce' ),
													$product->get_name() ), 'success' );
						}
					}

				}

			}
		}

		/**
		 * Add watchlist customer when user is redirected to my account page
		 *
		 * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
		 * @since 2.0
		 */
		public function add_watchlist_notice() {
			if( 'yes' == get_option( 'yith_wcact_settings_enable_watchlist', 'no' ) &&  isset( $_GET['watchlist_notice'] ) && $_GET['watchlist_notice'] == true && ! isset( $_POST['login'] ) && ! isset( $_POST['register'] ) ){
				wc_add_notice( apply_filters( 'yith_wcact_watchlist_register_user_message', __( 'Please, log in to use the watchlist feature', 'yith-auctions-for-woocommerce' ) ), 'error' );
			}
		}

		/**
		 * Value step for increment and decrement plugin buttons
		 *
		 * @author Carlos Rodríguez <carlos.rodriguez@yithemes.com>
		 * @since 2.0.4
		 */
		public function bid_value_step_for_plugin_buttons($value) {
			global $post;

			$product = wc_get_product($post);

			if( is_product() && $product && 'auction' == $product->get_type() ) {

				$minimun_increment_amount = (int) $product->get_minimum_increment_amount();

				if ( isset($minimun_increment_amount) && $minimun_increment_amount ) {

					$value = $minimun_increment_amount;
				}

			}


			return $value;
		}
    }
}
